# La Liga Match Predictor

This is a machine learning application that predicts the outcome of La Liga football matches using historical data from the 2022/23 and 2023/24 seasons.

## Features

- Predicts match outcomes (win/draw/loss)
- Predicts actual match scores (like 3-2, 1-1)
- Shows probability breakdown for different outcomes
- Provides insights based on team performance data

## Installation

1. Clone or download this repository
2. Install the required packages:

```
pip install -r requirements_to_install.txt
```

3. Run the application:

```
streamlit run app.py
```

## Files

- `app.py` - Main application entry point with UI
- `data_processor.py` - Loads and processes match data
- `ml_model.py` - Machine learning model implementation
- `utils.py` - Helper functions for team stats and visualization

## Data Source

The application fetches data from football-data.co.uk, a reliable source for historical football match data.

## Running Locally

1. Make sure you have Python 3.8+ installed
2. Install dependencies using pip
3. Run the application using Streamlit
4. Access the app at http://localhost:8501 in your browser