import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import pickle
import os
from data_processor import fetch_laliga_data, preprocess_data
from ml_model import train_model, train_score_prediction_models, predict_outcome
from utils import get_laliga_teams, create_team_stats, display_prediction_results

# Set page configuration
st.set_page_config(
    page_title="La Liga Match Predictor",
    page_icon="⚽",
    layout="wide"
)

# App title and description
st.title("⚽ La Liga Match Outcome Predictor")
st.markdown("""
This application predicts the outcome of La Liga football matches using machine learning algorithms
trained on data from the 2022/23 and 2023/24 seasons.
""")

# Sidebar for model info and stats
with st.sidebar:
    st.header("About the Model")
    st.info("""
    This model is trained on actual La Liga match data from the 2022/23 and 2023/24 seasons.
    It considers various factors including:
    - Team's home and away performance
    - Goals scored and conceded
    - Recent form and standings
    
    The prediction includes both the match outcome (win/lose/draw) and the most likely final score.
    """)
    
    # Model metrics display (will be populated after training)
    st.header("Model Performance")
    model_metrics_container = st.empty()

# Initialize session state for storing data and model
if 'data_loaded' not in st.session_state:
    st.session_state.data_loaded = False

if 'model_trained' not in st.session_state:
    st.session_state.model_trained = False
    
if 'model' not in st.session_state:
    st.session_state.model = None
    
if 'teams' not in st.session_state:
    st.session_state.teams = []
    
if 'team_stats' not in st.session_state:
    st.session_state.team_stats = {}
    
if 'X_scaler' not in st.session_state:
    st.session_state.X_scaler = None

# Data loading and model training section
with st.expander("Data Loading and Model Training", expanded=not st.session_state.data_loaded):
    if not st.session_state.data_loaded:
        if st.button("Load La Liga Data & Train Model"):
            with st.spinner("Fetching and processing La Liga data..."):
                # Fetch and preprocess data
                matches_df = fetch_laliga_data()
                
                if matches_df is not None and not matches_df.empty:
                    # Get processed data
                    X_train, X_test, y_train, y_test, home_train, away_train, X_scaler, teams = preprocess_data(matches_df)
                    
                    # Train model
                    with st.spinner("Training machine learning model..."):
                        model, metrics = train_model(X_train, y_train, X_test, y_test)
                        
                        # Train score prediction models
                        with st.spinner("Training score prediction models..."):
                            home_score_model, away_score_model = train_score_prediction_models(X_train, home_train, away_train)
                            
                            # Save score prediction models
                            st.session_state.home_score_model = home_score_model
                            st.session_state.away_score_model = away_score_model
                        
                        # Save model and relevant data to session state
                        st.session_state.model = model
                        st.session_state.X_scaler = X_scaler
                        st.session_state.teams = teams
                        st.session_state.metrics = metrics
                        st.session_state.matches_df = matches_df
                        
                        # Calculate team statistics for reference
                        st.session_state.team_stats = create_team_stats(matches_df, teams)
                        
                        # Update session state
                        st.session_state.data_loaded = True
                        st.session_state.model_trained = True
                        
                        # Display metrics in sidebar
                        model_metrics_container.success(f"""
                        **Model Accuracy:** {metrics['accuracy']:.2f}
                        
                        **Classification Report:**
                        {metrics['classification_report']}
                        """)
                else:
                    st.error("Failed to load data. Please try again later.")
    else:
        st.success("✅ Data loaded and model trained successfully!")

# Team selection and prediction section (only shown after data is loaded)
if st.session_state.data_loaded and st.session_state.model_trained:
    st.markdown("## Predict Match Outcome")
    st.markdown("Select two teams to predict the outcome of a match between them:")
    
    # Team selection
    col1, col2 = st.columns(2)
    
    with col1:
        home_team = st.selectbox("Home Team", st.session_state.teams, index=0)
    
    with col2:
        # Filter to not select the same team
        away_teams = [team for team in st.session_state.teams if team != home_team]
        away_team = st.selectbox("Away Team", away_teams, index=0)
    
    # Prediction button
    if st.button("Predict Match Outcome"):
        with st.spinner("Predicting match outcome..."):
            # Make prediction
            prediction, probabilities, score_prediction = predict_outcome(
                home_team,
                away_team,
                st.session_state.model,
                st.session_state.X_scaler,
                st.session_state.teams
            )
            
            # Display prediction results
            display_prediction_results(
                home_team,
                away_team,
                prediction,
                probabilities,
                st.session_state.team_stats,
                score_prediction
            )
else:
    if not st.session_state.data_loaded:
        st.info("👆 First, load the data and train the model using the section above.")
