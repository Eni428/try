import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def get_laliga_teams():
    """
    Get the list of La Liga teams for the 2022-2024 seasons.
    This is a fallback if data fetching fails.
    
    Returns:
        list: List of team names
    """
    # La Liga teams for 2022-2024 seasons
    teams = [
        "Athletic Bilbao", "Atletico Madrid", "Barcelona", "Cadiz", 
        "Celta Vigo", "Espanyol", "Getafe", "Granada", "Mallorca", 
        "Osasuna", "Rayo Vallecano", "Real Betis", "Real Madrid", 
        "Real Sociedad", "Sevilla", "Valencia", "Villarreal",
        "Alaves", "Almeria", "Elche", "Girona", "Las Palmas", 
        "Leganes", "Levante", "Real Valladolid"
    ]
    return sorted(teams)

def create_team_stats(matches_df, teams):
    """
    Create team statistics from match data.
    
    Args:
        matches_df (pandas.DataFrame): DataFrame with match data
        teams (list): List of team names
        
    Returns:
        dict: Dictionary with team statistics
    """
    team_stats = {}
    
    for team in teams:
        # Home matches
        home_matches = matches_df[matches_df['home_team'] == team]
        home_wins = sum(home_matches['result'] == 'H')
        home_draws = sum(home_matches['result'] == 'D')
        home_losses = sum(home_matches['result'] == 'A')
        
        # Away matches
        away_matches = matches_df[matches_df['away_team'] == team]
        away_wins = sum(away_matches['result'] == 'A')
        away_draws = sum(away_matches['result'] == 'D')
        away_losses = sum(away_matches['result'] == 'H')
        
        # Goals
        goals_scored_home = home_matches['home_score'].sum()
        goals_conceded_home = home_matches['away_score'].sum()
        
        goals_scored_away = away_matches['away_score'].sum()
        goals_conceded_away = away_matches['home_score'].sum()
        
        # Create averages
        home_matches_count = len(home_matches)
        away_matches_count = len(away_matches)
        
        avg_goals_scored_home = goals_scored_home / home_matches_count if home_matches_count > 0 else 0
        avg_goals_conceded_home = goals_conceded_home / home_matches_count if home_matches_count > 0 else 0
        
        avg_goals_scored_away = goals_scored_away / away_matches_count if away_matches_count > 0 else 0
        avg_goals_conceded_away = goals_conceded_away / away_matches_count if away_matches_count > 0 else 0
        
        # Calculate form (points in last 5 matches)
        all_team_matches = pd.concat([
            home_matches[['date', 'home_team', 'away_team', 'result']].assign(is_home=True),
            away_matches[['date', 'home_team', 'away_team', 'result']].assign(is_home=False)
        ]).sort_values('date', ascending=False)
        
        last_5_matches = all_team_matches.head(5)
        form_points = 0
        
        for _, match in last_5_matches.iterrows():
            if match['is_home']:
                if match['result'] == 'H':
                    form_points += 3
                elif match['result'] == 'D':
                    form_points += 1
            else:
                if match['result'] == 'A':
                    form_points += 3
                elif match['result'] == 'D':
                    form_points += 1
        
        max_possible_points = len(last_5_matches) * 3
        form = form_points / max_possible_points if max_possible_points > 0 else 0
        
        # Calculate home and away advantage
        home_advantage = home_wins / home_matches_count if home_matches_count > 0 else 0.5
        away_advantage = away_wins / away_matches_count if away_matches_count > 0 else 0.5
        
        # Store stats
        team_stats[team] = {
            'home_wins': home_wins,
            'home_draws': home_draws,
            'home_losses': home_losses,
            'away_wins': away_wins,
            'away_draws': away_draws,
            'away_losses': away_losses,
            'avg_goals_scored_home': avg_goals_scored_home,
            'avg_goals_conceded_home': avg_goals_conceded_home,
            'avg_goals_scored_away': avg_goals_scored_away,
            'avg_goals_conceded_away': avg_goals_conceded_away,
            'form': form,
            'home_advantage': home_advantage,
            'away_advantage': away_advantage
        }
    
    return team_stats

def display_prediction_results(home_team, away_team, prediction, probabilities, team_stats, score_prediction=None):
    """
    Display prediction results in Streamlit.
    
    Args:
        home_team (str): Home team name
        away_team (str): Away team name
        prediction (str): Predicted outcome (H/A/D)
        probabilities (dict): Prediction probabilities
        team_stats (dict): Team statistics
        score_prediction (dict, optional): Score prediction details
    """
    # Define outcome texts
    outcome_text = {
        'H': f"**{home_team}** Win",
        'D': "Draw",
        'A': f"**{away_team}** Win"
    }
    
    # Display the prediction in a visually appealing way
    st.markdown("---")
    st.subheader("🔮 Prediction Result")
    
    # Create columns for the display
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col1:
        st.markdown(f"### {home_team}")
        st.markdown("Home Team")
    
    with col3:
        st.markdown(f"### {away_team}")
        st.markdown("Away Team")
    
    with col2:
        # Display the predicted score if available
        if score_prediction:
            predicted_score = score_prediction['predicted_score']
            home_goals, away_goals = predicted_score.split('-')
            
            st.markdown(f"## Predicted Score: {home_goals}-{away_goals}")
            st.markdown(f"### ({outcome_text.get(prediction, prediction)})")
            
            # Create a more visual representation of the score
            score_col1, score_col2, score_col3 = st.columns([1, 1, 1])
            with score_col1:
                st.markdown(f"<h1 style='text-align: center;'>{home_goals}</h1>", unsafe_allow_html=True)
            
            with score_col2:
                st.markdown("<h1 style='text-align: center;'>-</h1>", unsafe_allow_html=True)
            
            with score_col3:
                st.markdown(f"<h1 style='text-align: center;'>{away_goals}</h1>", unsafe_allow_html=True)
                
            # Display expected goals
            st.markdown(f"#### Expected Goals (xG)")
            st.markdown(f"- **{home_team}**: {score_prediction['home_xg']:.1f} xG")
            st.markdown(f"- **{away_team}**: {score_prediction['away_xg']:.1f} xG")
            
            # Display other probable scores
            st.markdown("#### Other Probable Scores")
            other_scores = score_prediction['top_scores'][1:5]  # Skip the most likely score which is already displayed
            
            for score, prob in other_scores:
                st.markdown(f"- **{score}**: {prob:.1f}%")
        else:
            # Display the predicted outcome prominently (fallback if score prediction not available)
            st.markdown(f"## Predicted Outcome: {outcome_text.get(prediction, prediction)}")
        
        # Display probabilities in percentage
        st.markdown("### Probability Breakdown")
        
        # Check if all expected keys exist in probabilities
        if all(key in probabilities for key in ['H', 'D', 'A']):
            # Home win probability
            home_win_prob = probabilities['H'] * 100
            # Draw probability
            draw_prob = probabilities['D'] * 100
            # Away win probability
            away_win_prob = probabilities['A'] * 100
            
            # Create a bar chart for probabilities
            fig, ax = plt.subplots(figsize=(10, 5))
            
            labels = [f"{home_team} Win", "Draw", f"{away_team} Win"]
            values = [home_win_prob, draw_prob, away_win_prob]
            colors = ['#1f77b4', '#2ca02c', '#d62728']
            
            ax.bar(labels, values, color=colors)
            ax.set_ylabel('Probability (%)')
            ax.set_title('Match Outcome Probabilities')
            
            # Add percentage labels on top of bars
            for i, v in enumerate(values):
                ax.text(i, v + 1, f"{v:.1f}%", ha='center')
            
            # Set y-axis to go to 100%
            ax.set_ylim(0, 100)
            
            st.pyplot(fig)
            
            # Display exact percentages
            st.markdown(f"""
            - **{home_team} Win**: {home_win_prob:.1f}%
            - **Draw**: {draw_prob:.1f}%
            - **{away_team} Win**: {away_win_prob:.1f}%
            """)
        else:
            # Fallback display if probabilities dict doesn't have expected keys
            for outcome, prob in probabilities.items():
                st.markdown(f"- **{outcome_text.get(outcome, outcome)}**: {prob*100:.1f}%")
    
    # Display additional insights based on team stats
    st.markdown("### 📊 Match Analysis")
    
    insights = []
    
    # Form comparison
    if home_team in team_stats and away_team in team_stats:
        home_form = team_stats[home_team]['form']
        away_form = team_stats[away_team]['form']
        
        if home_form > away_form + 0.2:
            insights.append(f"🔥 {home_team} has been in better form recently compared to {away_team}.")
        elif away_form > home_form + 0.2:
            insights.append(f"🔥 {away_team} has been in better form recently compared to {home_team}.")
        else:
            insights.append(f"📊 Both teams have been showing similar form recently.")
        
        # Home/Away performance
        home_advantage = team_stats[home_team]['home_advantage']
        away_advantage = team_stats[away_team]['away_advantage']
        
        if home_advantage > 0.6:
            insights.append(f"🏠 {home_team} has a strong home record this season.")
        
        if away_advantage > 0.5:
            insights.append(f"🛣️ {away_team} performs well in away matches.")
        
        # Scoring patterns
        home_goals_scored = team_stats[home_team]['avg_goals_scored_home']
        away_goals_scored = team_stats[away_team]['avg_goals_scored_away']
        
        if home_goals_scored > 1.5:
            insights.append(f"⚽ {home_team} tends to score well at home, averaging {home_goals_scored:.1f} goals per game.")
        
        if away_goals_scored > 1.5:
            insights.append(f"⚽ {away_team} has strong scoring away from home, averaging {away_goals_scored:.1f} goals per game.")
    
    # Display insights
    if insights:
        for insight in insights:
            st.markdown(f"- {insight}")
    else:
        st.markdown("No additional insights available for this matchup.")
