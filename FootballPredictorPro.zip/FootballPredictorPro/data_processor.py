import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import requests
from io import StringIO
import streamlit as st

def fetch_laliga_data():
    """
    Fetches La Liga match data from 2022-2024 seasons.
    
    Returns:
        pandas.DataFrame: DataFrame containing La Liga match data
    """
    try:
        # URLs for CSV data of La Liga matches (2022-2024)
        laliga_2022_2023_url = "https://www.football-data.co.uk/mmz4281/2223/SP1.csv"
        laliga_2023_2024_url = "https://www.football-data.co.uk/mmz4281/2324/SP1.csv"
        
        # Fetch data
        response_2223 = requests.get(laliga_2022_2023_url)
        response_2324 = requests.get(laliga_2023_2024_url)
        
        if response_2223.status_code != 200 or response_2324.status_code != 200:
            st.error("Failed to fetch data from the source.")
            return None
        
        # Read CSVs
        df_2223 = pd.read_csv(StringIO(response_2223.text))
        df_2324 = pd.read_csv(StringIO(response_2324.text))
        
        # Add season information
        df_2223['Season'] = '2022-2023'
        df_2324['Season'] = '2023-2024'
        
        # Combine datasets
        matches_df = pd.concat([df_2223, df_2324], ignore_index=True)
        
        # Select and rename relevant columns
        matches_df = matches_df.rename(columns={
            'Date': 'date',
            'HomeTeam': 'home_team',
            'AwayTeam': 'away_team',
            'FTHG': 'home_score',
            'FTAG': 'away_score',
            'FTR': 'result'  # H=Home Win, A=Away Win, D=Draw
        })
        
        # Select only needed columns
        matches_df = matches_df[['date', 'home_team', 'away_team', 'home_score', 'away_score', 'result', 'Season']]
        
        # Convert date to datetime
        matches_df['date'] = pd.to_datetime(matches_df['date'], errors='coerce')
        
        # Sort by date
        matches_df = matches_df.sort_values('date').reset_index(drop=True)
        
        return matches_df
    
    except Exception as e:
        st.error(f"Error fetching data: {e}")
        return None

def calculate_team_features(matches_df):
    """
    Calculate team-specific features for model training.
    
    Args:
        matches_df (pandas.DataFrame): DataFrame containing match data
        
    Returns:
        pandas.DataFrame: DataFrame with calculated team features
    """
    # Get unique teams
    teams = sorted(list(set(matches_df['home_team'].unique()) | set(matches_df['away_team'].unique())))
    
    # Create a rolling window of matches to calculate form
    matches_with_features = []
    
    for idx, match in matches_df.iterrows():
        home_team = match['home_team']
        away_team = match['away_team']
        match_date = match['date']
        
        # Get previous matches for each team (up to 5 for form calculation)
        home_previous = matches_df[
            ((matches_df['home_team'] == home_team) | (matches_df['away_team'] == home_team)) & 
            (matches_df['date'] < match_date)
        ].tail(5)
        
        away_previous = matches_df[
            ((matches_df['home_team'] == away_team) | (matches_df['away_team'] == away_team)) & 
            (matches_df['date'] < match_date)
        ].tail(5)
        
        # Calculate home team features
        home_features = {
            'home_team_form': calculate_form(home_previous, home_team),
            'home_team_avg_goals_scored': calculate_avg_goals_scored(home_previous, home_team),
            'home_team_avg_goals_conceded': calculate_avg_goals_conceded(home_previous, home_team),
            'home_team_home_adv': calculate_home_advantage(home_previous, home_team)
        }
        
        # Calculate away team features
        away_features = {
            'away_team_form': calculate_form(away_previous, away_team),
            'away_team_avg_goals_scored': calculate_avg_goals_scored(away_previous, away_team),
            'away_team_avg_goals_conceded': calculate_avg_goals_conceded(away_previous, away_team),
            'away_team_away_adv': calculate_away_advantage(away_previous, away_team)
        }
        
        # Create enhanced match record with features
        enhanced_match = match.to_dict()
        enhanced_match.update(home_features)
        enhanced_match.update(away_features)
        
        matches_with_features.append(enhanced_match)
    
    # Convert to DataFrame
    enhanced_df = pd.DataFrame(matches_with_features)
    
    # Fill NaN values for first few matches where historical data might be missing
    numeric_cols = enhanced_df.select_dtypes(include=[np.number]).columns
    enhanced_df[numeric_cols] = enhanced_df[numeric_cols].fillna(0)
    
    return enhanced_df, teams

def calculate_form(previous_matches, team):
    """Calculate form based on last matches (3 pts for win, 1 for draw, 0 for loss)"""
    if previous_matches.empty:
        return 0
    
    form_points = 0
    for _, match in previous_matches.iterrows():
        if match['home_team'] == team:
            if match['result'] == 'H':
                form_points += 3
            elif match['result'] == 'D':
                form_points += 1
        else:  # Away team
            if match['result'] == 'A':
                form_points += 3
            elif match['result'] == 'D':
                form_points += 1
    
    # Normalize by max possible points
    max_points = len(previous_matches) * 3
    return (form_points / max_points) if max_points > 0 else 0

def calculate_avg_goals_scored(previous_matches, team):
    """Calculate average goals scored by team in previous matches"""
    if previous_matches.empty:
        return 0
    
    total_goals = 0
    for _, match in previous_matches.iterrows():
        if match['home_team'] == team:
            total_goals += match['home_score']
        else:
            total_goals += match['away_score']
    
    return total_goals / len(previous_matches)

def calculate_avg_goals_conceded(previous_matches, team):
    """Calculate average goals conceded by team in previous matches"""
    if previous_matches.empty:
        return 0
    
    total_goals = 0
    for _, match in previous_matches.iterrows():
        if match['home_team'] == team:
            total_goals += match['away_score']
        else:
            total_goals += match['home_score']
    
    return total_goals / len(previous_matches)

def calculate_home_advantage(previous_matches, team):
    """Calculate home advantage (win rate at home)"""
    if previous_matches.empty:
        return 0.5  # Neutral
    
    home_matches = previous_matches[previous_matches['home_team'] == team]
    if home_matches.empty:
        return 0.5  # Neutral
    
    home_wins = sum(home_matches['result'] == 'H')
    return home_wins / len(home_matches)

def calculate_away_advantage(previous_matches, team):
    """Calculate away advantage (win rate away)"""
    if previous_matches.empty:
        return 0.5  # Neutral
    
    away_matches = previous_matches[previous_matches['away_team'] == team]
    if away_matches.empty:
        return 0.5  # Neutral
    
    away_wins = sum(away_matches['result'] == 'A')
    return away_wins / len(away_matches)

def prepare_features_and_target(enhanced_df):
    """
    Prepare features and target variables for machine learning.
    
    Args:
        enhanced_df (pandas.DataFrame): DataFrame with calculated features
        
    Returns:
        tuple: X (features) and y (target) for machine learning
    """
    # Features for prediction
    feature_columns = [
        'home_team_form', 'home_team_avg_goals_scored', 'home_team_avg_goals_conceded', 'home_team_home_adv',
        'away_team_form', 'away_team_avg_goals_scored', 'away_team_avg_goals_conceded', 'away_team_away_adv'
    ]
    
    # Target
    target_column = 'result'
    
    # Get features and target
    X = enhanced_df[feature_columns]
    y = enhanced_df[target_column]
    
    return X, y

def preprocess_data(matches_df):
    """
    Preprocess data for machine learning.
    
    Args:
        matches_df (pandas.DataFrame): Raw match data
        
    Returns:
        tuple: Processed data ready for model training
    """
    # Calculate features
    enhanced_df, teams = calculate_team_features(matches_df)
    
    # Prepare features and target
    X, y = prepare_features_and_target(enhanced_df)
    
    # Get home and away scores for score prediction
    home_scores = enhanced_df['home_score']
    away_scores = enhanced_df['away_score']
    
    # Split data
    X_train, X_test, y_train, y_test, home_train, home_test, away_train, away_test = train_test_split(
        X, y, home_scores, away_scores, test_size=0.2, random_state=42
    )
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    return X_train_scaled, X_test_scaled, y_train, y_test, home_train, away_train, scaler, teams
