import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, mean_squared_error
import streamlit as st
from scipy.stats import poisson

def train_model(X_train, y_train, X_test, y_test):
    """
    Train a machine learning model for match outcome prediction.
    
    Args:
        X_train, y_train: Training data
        X_test, y_test: Testing data
        
    Returns:
        tuple: Trained model and performance metrics
    """
    # Initialize the model (Random Forest Classifier)
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        random_state=42,
        class_weight='balanced'
    )
    
    # Train the model
    model.fit(X_train, y_train)
    
    # Make predictions on test set
    y_pred = model.predict(X_test)
    
    # Calculate metrics
    accuracy = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred)
    conf_matrix = confusion_matrix(y_test, y_pred)
    
    # Store metrics
    metrics = {
        'accuracy': accuracy,
        'classification_report': report,
        'confusion_matrix': conf_matrix
    }
    
    return model, metrics

def train_score_prediction_models(X_train, home_scores, away_scores):
    """
    Train models to predict the actual score of a match.
    
    Args:
        X_train: Training features
        home_scores: Home team scores for training
        away_scores: Away team scores for training
        
    Returns:
        tuple: Trained home score model and away score model
    """
    # Initialize models for score prediction
    home_score_model = RandomForestRegressor(
        n_estimators=100, 
        max_depth=8,
        random_state=42
    )
    
    away_score_model = RandomForestRegressor(
        n_estimators=100,
        max_depth=8,
        random_state=42
    )
    
    # Train models
    home_score_model.fit(X_train, home_scores)
    away_score_model.fit(X_train, away_scores)
    
    return home_score_model, away_score_model

def predict_outcome(home_team, away_team, model, scaler, teams):
    """
    Predict the outcome of a match between home_team and away_team.
    
    Args:
        home_team (str): Name of the home team
        away_team (str): Name of the away team
        model: Trained machine learning model
        scaler: Feature scaler
        teams (list): List of all teams
        
    Returns:
        tuple: Predicted outcome and probability scores
    """
    # Get team stats from session state if available
    team_stats = st.session_state.get('team_stats', {})
    
    # Default values if stats not available
    home_form = 0.5
    home_goals_scored = 1.0
    home_goals_conceded = 1.0
    home_advantage = 0.6
    
    away_form = 0.5
    away_goals_scored = 1.0
    away_goals_conceded = 1.0
    away_advantage = 0.4
    
    # Update with actual stats if available
    if home_team in team_stats:
        home_form = team_stats[home_team].get('form', 0.5)
        home_goals_scored = team_stats[home_team].get('avg_goals_scored_home', 1.0)
        home_goals_conceded = team_stats[home_team].get('avg_goals_conceded_home', 1.0)
        home_advantage = team_stats[home_team].get('home_advantage', 0.6)
    
    if away_team in team_stats:
        away_form = team_stats[away_team].get('form', 0.5)
        away_goals_scored = team_stats[away_team].get('avg_goals_scored_away', 1.0)
        away_goals_conceded = team_stats[away_team].get('avg_goals_conceded_away', 1.0)
        away_advantage = team_stats[away_team].get('away_advantage', 0.4)
    
    # Create feature vector
    match_features = np.array([
        home_form, 
        home_goals_scored, 
        home_goals_conceded, 
        home_advantage,
        away_form, 
        away_goals_scored, 
        away_goals_conceded, 
        away_advantage
    ]).reshape(1, -1)
    
    # Scale features
    scaled_features = scaler.transform(match_features)
    
    # Predict probabilities
    prediction_probs = model.predict_proba(scaled_features)[0]
    
    # Get predicted outcome
    prediction = model.predict(scaled_features)[0]
    
    # Get class labels
    classes = model.classes_
    
    # Create probabilities dict
    probabilities = {class_label: prob for class_label, prob in zip(classes, prediction_probs)}
    
    # Get score prediction models from session state
    home_score_model = st.session_state.get('home_score_model')
    away_score_model = st.session_state.get('away_score_model')
    
    # Calculate score prediction
    score_prediction = predict_score(match_features, scaler, home_team, away_team)
    
    return prediction, probabilities, score_prediction

def predict_score(features, scaler, home_team, away_team):
    """
    Predict the actual score for a match.
    
    Args:
        features: Match features
        scaler: Feature scaler
        home_team: Home team name
        away_team: Away team name
        
    Returns:
        dict: Predicted scores and probabilities
    """
    # Scale features
    scaled_features = scaler.transform(features)
    
    # Get regression models for score prediction
    home_score_model = st.session_state.get('home_score_model')
    away_score_model = st.session_state.get('away_score_model')
    
    # Default to statistical method if models not available
    if home_score_model is None or away_score_model is None:
        return predict_score_statistical(features, scaler, home_team, away_team)
    
    # Predict using regression models
    home_pred = home_score_model.predict(scaled_features)[0]
    away_pred = away_score_model.predict(scaled_features)[0]
    
    # Round predictions to nearest integer
    home_xg = max(0, round(home_pred, 1))
    away_xg = max(0, round(away_pred, 1))
    
    # Get most likely exact score (round to integers)
    home_score = round(home_pred)
    away_score = round(away_pred)
    
    # Generate score probabilities using Poisson distribution
    score_probs = {}
    
    # Calculate probabilities for scores from 0-0 to 5-5
    for h in range(6):
        for a in range(6):
            # Calculate probability of this score using Poisson distribution
            prob = poisson.pmf(h, home_xg) * poisson.pmf(a, away_xg)
            score_probs[f"{h}-{a}"] = prob
    
    # Convert to percentages and sort by probability
    score_probs = {k: v * 100 for k, v in score_probs.items()}
    sorted_scores = sorted(score_probs.items(), key=lambda x: x[1], reverse=True)
    
    # Get most likely scores (top 5)
    top_scores = sorted_scores[:5]
    
    return {
        'predicted_score': f"{home_score}-{away_score}",
        'home_xg': home_xg,
        'away_xg': away_xg,
        'top_scores': top_scores
    }

def predict_score_statistical(features, scaler, home_team, away_team):
    """
    Predict score using statistical method (fallback if ML models not available)
    
    Args:
        features: Match features
        scaler: Feature scaler
        home_team: Home team name
        away_team: Away team name
        
    Returns:
        dict: Predicted scores and probabilities
    """
    # Get team stats
    team_stats = st.session_state.get('team_stats', {})
    
    # Calculate expected goals using team statistics
    home_xg = 0
    away_xg = 0
    
    if home_team in team_stats and away_team in team_stats:
        # Home team's expected goals (their avg. scored * away team's avg. conceded)
        home_xg = (team_stats[home_team].get('avg_goals_scored_home', 1.0) + 
                  team_stats[away_team].get('avg_goals_conceded_away', 1.0)) / 2
        
        # Away team's expected goals (their avg. scored * home team's avg. conceded)
        away_xg = (team_stats[away_team].get('avg_goals_scored_away', 1.0) + 
                  team_stats[home_team].get('avg_goals_conceded_home', 1.0)) / 2
    else:
        # Default values if team stats not available
        home_xg = 1.5
        away_xg = 1.0
    
    # Adjust based on form
    if home_team in team_stats:
        home_form = team_stats[home_team].get('form', 0.5)
        home_xg *= (0.5 + home_form)  # 0.5-1.5 multiplier based on form
    
    if away_team in team_stats:
        away_form = team_stats[away_team].get('form', 0.5)
        away_xg *= (0.5 + away_form)  # 0.5-1.5 multiplier based on form
    
    # Round to nearest 0.1 for display
    home_xg = round(home_xg, 1)
    away_xg = round(away_xg, 1)
    
    # Generate score probabilities using Poisson distribution
    score_probs = {}
    most_likely_score = (0, 0)
    max_prob = 0
    
    # Calculate probabilities for scores from 0-0 to 5-5
    for h in range(6):
        for a in range(6):
            # Calculate probability of this score using Poisson distribution
            prob = poisson.pmf(h, home_xg) * poisson.pmf(a, away_xg)
            score_probs[f"{h}-{a}"] = prob
            
            # Track most likely score
            if prob > max_prob:
                max_prob = prob
                most_likely_score = (h, a)
    
    # Convert to percentages and sort by probability
    score_probs = {k: v * 100 for k, v in score_probs.items()}
    sorted_scores = sorted(score_probs.items(), key=lambda x: x[1], reverse=True)
    
    # Get most likely scores (top 5)
    top_scores = sorted_scores[:5]
    
    return {
        'predicted_score': f"{most_likely_score[0]}-{most_likely_score[1]}",
        'home_xg': home_xg,
        'away_xg': away_xg,
        'top_scores': top_scores
    }
